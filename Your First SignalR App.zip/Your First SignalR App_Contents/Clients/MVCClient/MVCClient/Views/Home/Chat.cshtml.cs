﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MVCClient.Views.Home;

public class Chat : PageModel
{
    public void OnGet()
    {
        
    }
}